<!DOCTYPE html>
<html lang="en">
<head>
<title>MNRGES registration </title>
    <!-- Meta tags -->
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Talent Application Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- Meta tags -->
    <!--stylesheets-->
<link href="css/style.css" rel='stylesheet' type='text/css' media="all">
<!--//style sheet end here-->
<!-- Calendar -->
<link rel="stylesheet" href="css/jquery-ui.css" />
<!-- //Calendar -->

<link href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<script>
function validateForm() {
  var x = document.forms["myform"]["name"].value;
  if (x == "" || x == null) {
    alert("Name must be filled out");
    return false;
  }
  var x = document.forms["myform"]["mobile"].value;
  if (x == "" || x == null) {
    alert("phone must be filled out");
    return false;
  }
  var x = document.forms["myform"]["Address"].value;
  if (x == "" || x == null) {
    alert("Address must be filled out");
    return false;
  }
  var x = document.forms["myform"]["panchayath"].value;
  if (x == "" || x == null) {
    alert("panchayath be filled out");
    return false;
  }
  var x = document.forms["myform"]["ward"].value;
  if (x == "" || x == null) {
    alert("ward must be filled out");
    return false;
  }
  var x = document.forms["myform"]["aadhra_no"].value;
  if (x == "" || x == null) {
    alert("Aadaarnumber must be filled out");
    return false;
  }
  var x = document.forms["myform"]["Card_no"].value;
  if (x == "" || x == null) {
    alert("Cardnumber must be filled out");
    return false;
  }
  var x = document.forms["myform"]["username"].value;
  if (x == "" || x == null) {
    alert("username must be filled out");
    return false;
  }
  var x = document.forms["myform"]["password"].value;
  if (x == "" || x == null) {
    alert("password must be filled out");
    return false;
  }
 
}
</script>
</head>
<body>
     <h1 class="header-w3ls">
Registration Form</h1>
<div class="appointment-w3">
    <form action="" method="post" name="myform" onsubmit="return validateForm()" enctype="multipart/form-data">

       <div class="personal">

         <h2>Personal Details</h2>
                    <div class="form-left-w3l">
                    <p>Name</p>
                        <input type="text" name="name" placeholder="Name" >
                    </div>
                       <div class="form-right-w3ls ">
                   
                    <p>Gender</p>
                    <select class="form-control" name="gender">
                    <option value="">Select Gender</option>
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                         <div class="clear"></div>
                    </div>
                    <div class="form-right-w3ls">
            <p>Date of Birth</p>
            <script>
function getAge() {
var dateString = document.getElementById("dob").value;
if(dateString !="")
{
    var today = new Date()
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    var da = today.getDate() - birthDate.getDate();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    if(m<0){
        m +=12;
    }
    if(da<0){
        da +=30;
    }

  if(age < 18 || age > 65)
{
alert("Age "+age+" is restrict");

} else {

alert("Age "+age+" is allowed");
}
} else {
alert("please provide your date of birth");
}
}


</script>

<input type="date" name="dob" id="dob" placeholder="dob" value="1987/08/31" onblur="getAge()">
            </div>  

        <div class="form-left-w3l ">    
            <p>Phone</p>
            <script>
                function validate_phone_number($phone)
{
     // Allow +, - and . in phone number
     $filtered_phone_number = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
     // Remove "-" from number
     $phone_to_check = str_replace("-", "", $filtered_phone_number);

     // Check the lenght of number
     // This can be customized if you want phone number from a specific country
     if (strlen($phone_to_check) < 10 || strlen($phone_to_check) > 14) {
        return false;
     } else {
       return true;
     }
}
            </script>
            <input  type="text" name="mobile" id="phone" placeholder="Phone Number" >
            </div>
           
           <div class="clear"></div>
         
           
            <div class="form-add-w3ls">
            <p>Address</p>
            <input type="text" name="Address" placeholder="Address" >
            </div>
            <div class="form-right-w3ls ">
            <p>Panchayath</p>
            <input type="text"  name="panchayath" placeholder="panchayath">
            </div>
            <div class="form-left-w3l ">
            <p>Ward</p>
            <input type="text"  name="ward" placeholder="ward">
            </div>
            <div class="clear"></div>
            <div class="form-right-w3ls ">
            <p>Adhar_no</p>
           
            <input type="text"  name="aadhar_no" placeholder="Adhar_no"  >
            </div>
            <div class="form-left-w3l ">
            <p>Card_no</p>
            <input type="text"  name="Card_no" placeholder="Card_no" >
            </div>
           
            <br>
            <div class="form-left-w3l ">    
            <p>Upload Your profile pic  (upload .png,.jpg format)</p>
            <input type="file" name="img" placeholder="image" >
            </div>
            <div class="clear"></div>
         
     <!-- <div class="form-left-w3l ">  
            <p>Upload Your aadhar  (upload .doc,.pdf format)</p>
            <input type="file" name="aadhar" placeholder="aadhar" >
            </div>
            <div class="clear"></div>
     
      <div class="form-left-w3l ">  
            <p>Upload Your card (upload .doc,.pdf format)</p>
            <input type="file" name="card" placeholder="card" >
            </div>
            <div class="clear"></div>-->
       

      <div class="information">
          <h3> Account Settings</h3>
                 
            <div class="form-add-w3ls">
            <p>Username</p>
            <input type="text" name="username" placeholder="Username" >
            </div>
            <div class="form-left-w3l">
            <p>Password</p>
            <input type="password" name="password" placeholder="Password"  pattern ="([A-Za-z0-9]{6,15})">
            </div>
            <div class="form-right-w3ls ">  
            <p>Confirm Password</p>
            <input type="password" name="Cpw" placeholder="Confirm Password" >


            </div>
            <div class="clear"></div>
      </div>
     



           <input type="submit" value="submit" name="submit">
           
</form>

</div>

   
    <div class="copy">
   
</div>
<?php
error_reporting(E_ALL ^ E_NOTICE);  

/////////  connection page /////
require("Connection.php");
    $name=$_POST['name'];
    $Address=$_POST['Address'];
    $Gender=$_POST['gender'];  
    $Ward=$_POST['ward'];      
    $Panchayath=$_POST['panchayath'];
    $dob=$_POST['dob'];
    $Phn_no=$_POST['mobile'];
    $Adhar_no=$_POST['aadhar_no'];
    $Card_no=$_POST['Card_no'];
    $username=$_POST['username'];
    $pwd=$_POST['password'];
    $confirm=$_POST['Confirm Password'];
    $img=$_FILES["img"]["name"];
   
if(isset($_POST['submit']))
{
    $targetDir="../Uploads/";
    $targetFilePath=$targetDir.$img;
    move_uploaded_file($_FILES["img"]["tmp_name"],$targetFilePath);
 $sql="INSERT INTO `registration`( `name`, `Gender`, `Address`, `Ward`, `Panchayath`, `dob`, `Phn_no`, `Adhar_no`, `Card_no`,`img`) VALUES('$name','$Gender','$Address','$Ward','$Panchayath','$dob','$Phn_no','$Adhar_no','$Card_no','$img')";
 $result2 = mysqli_query($conn, $sql);
 $z=mysqli_insert_id($conn);
 $sql1="INSERT INTO `login`(`Username`, `password`, `status`, `role`, `reg_id`)
 VALUES ('$username','$pwd','1','1','$z')";
 $result3=mysqli_query($conn,$sql1);
 echo "<script>location='../../Login/Login1.html'</script>";
}


?>
        <!-- js -->
  <script type='text/javascript' src='js/jquery-2.2.3.min.js'></script>
<!-- //js -->
<!-- Calendar -->
                <link rel="stylesheet" href="css/jquery-ui.css" />
                <script src="js/jquery-ui.js"></script>
                  <script>
                          $(function() {
                            $( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
                          });
                  </script>
            <!-- //Calendar -->
</body>

</html>