<!DOCTYPE html>
<html lang="en">
<head>
<title>MNRGES  </title>
	<!-- Meta tags -->
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Talent Application Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Meta tags -->
	<!--stylesheets-->
<link href="css/style.css" rel='stylesheet' type='text/css' media="all">
<!--//style sheet end here-->
<!-- Calendar -->
<link rel="stylesheet" href="css/jquery-ui.css" />
<!-- //Calendar -->

<link href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<script>
function validateForm() {
  var x = document.forms["myform"]["name"].value;
  if (x == "" || x == null) {
    alert("Name must be filled out");
    return false;
  }
  var x = document.forms["myform"]["mobile"].value;
  if (x == "" || x == null) {
    alert("phone must be filled out");
    return false;
  }
  var x = document.forms["myform"]["Address"].value;
  if (x == "" || x == null) {
    alert("Address must be filled out");
    return false;
  }
  var x = document.forms["myform"]["panchayath"].value;
  if (x == "" || x == null) {
    alert("panchayath be filled out");
    return false;
  }
  var x = document.forms["myform"]["ward"].value;
  if (x == "" || x == null) {
    alert("ward must be filled out");
    return false;
  }
  var x = document.forms["myform"]["aadhra_no"].value;
  if (x == "" || x == null) {
    alert("Aadaarnumber must be filled out");
    return false;
  }
  var x = document.forms["myform"]["Card_no"].value;
  if (x == "" || x == null) {
    alert("Cardnumber must be filled out");
    return false;
  }
  var x = document.forms["myform"]["username"].value;
  if (x == "" || x == null) {
    alert("username must be filled out");
    return false;
  }
  var x = document.forms["myform"]["password"].value;
  if (x == "" || x == null) {
    alert("password must be filled out");
    return false;
  }
  
}
</script>
</head>
<body>
     <h1 class="header-w3ls">
Card Application form</h1>
<div class="appointment-w3">
    <form action="" method="post" name="myform" onsubmit="return validateForm()">

       <div class="personal">

  					<div class="form-left-w3l">
					<p>Name</p>
						<input type="text" name="name" placeholder="Name" >
					</div>
					   <div class="form-right-w3ls ">
					
					<p>Gender</p>
					<select class="form-control" name="gender">
					<option value="">Select Gender</option>
						<option>Male</option>
						<option>Female</option>
					</select>
						 <div class="clear"></div>
					</div>
					
  					<div class="form-right-w3ls">
					<p>House num</p>
						<input type="text" name="houseno" placeholder="houseno" >
					</div>
					  
					
					<!--<div class="form-right-w3ls">
			<p>Date of Birth</p>
			<script>
function getAge() {
var dateString = document.getElementById("dob").value;
if(dateString !="")
{
    var today = new Date()
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    var da = today.getDate() - birthDate.getDate();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    if(m<0){
        m +=12;
    }
    if(da<0){
        da +=30;
    }

  if(age < 18 || age > 100)
{
alert("Age "+age+" is restrict");

} else {

alert("Age "+age+" is allowed");
}
} else {
alert("please provide your date of birth");
}
}


</script>

<input type="date" name="dob" id="dob" placeholder="dob" value="1987/08/31" onblur="getAge()">
	        </div>	-->

        <div class="form-left-w3l ">	
			<p>Phone</p>
			<input  type="text" name="mobile" placeholder="Phone Number" required="">
		    </div>
		   
           <div class="clear"></div>
		  
		   
		    <div class="form-add-w3ls">	
			<p>Address</p>
			<input type="text" name="address" placeholder="Address" required="">
		    </div>
			<div class="form-right-w3ls ">
		    <p>Panchayath</p>
		    <input type="text"  name="panchayath" placeholder="panchayath" required="">
            </div>
			<div class="form-left-w3l ">
		    <p>Ward</p>
		    <input type="text"  name="ward" placeholder="ward" required="">
            </div>
			
			<div class="form-left-w3l">
					<p>Date</p>
						<input type="date"  name="date" placeholder="date"  required="">
					</div>
					  
			<div class="clear"></div>
			<div class="form-right-w3ls ">
		    <p>email</p>
		    <input type="text"  name="email" placeholder="email" required="">
            </div>
			
		    <div class="clear"></div>
			<div class="form-right-w3ls ">
		    <p>Photo  (upload .jpg,.png format)</p>
			<input type="file" name="aadhar" placeholder="aadhar" required="">
		    </div>
			<div class="clear"></div>
			
			
			<div class="form-left-w3l ">
		    <p>photo (upload .jpg,.png format)</p>
			<input type="file" name="photo"  placeholder="photo" required="">
		    </div>
			<div class="clear"></div>
	 	 
	 
	        <div class="clear"></div>
			<div class="form-right-w3ls ">
		    <p>rationcard (upload .jpg,.png format)</p>
			<input type="file" name="rcard" placeholder="rcard" required="">
		    </div>
			<div class="clear"></div>
	 	 
	 
			<!--<br>
			<div class="form-left-w3l ">	
			<p>Upload Your profile pic  (upload .doc,.pdf format)</p>
			<input type="file" name="profile" placeholder="profile" required="">
		    </div>
		    <div class="clear"></div>
		 
	  <div class="form-left-w3l ">	
			<p>Upload Your aadhar  (upload .doc,.pdf format)</p>
			<input type="file" name="aadhar" placeholder="aadhar" required="">
		    </div>
		    <div class="clear"></div>
	  
	  <div class="form-left-w3l ">	
			<p>Upload Your card (upload .doc,.pdf format)</p>
			<input type="file" name="card" placeholder="card" required="">
		    </div>
		    <div class="clear"></div>-->
		

     <!-- <div class="information">
          <h3> Account Settings</h3>
				 
			<div class="form-add-w3ls">	
			<p>Username</p>
			<input type="text" name="username" placeholder="Username" required="">
		    </div>
		    <div class="form-left-w3l">
			<p>Password</p>
		    <input type="password" name="password" placeholder="Password" required="" pattern ="([A-Za-z0-9]{6,15})">
			</div>
            <div class="form-right-w3ls ">	
			<p>Confirm Password</p>
			<input type="password" name="Cpw" placeholder="Confirm Password" required="">
		    </div>
		    <div class="clear"></div>
	  </div>-->
	 
	 

<div>

           <input type="submit" value="submit" name="submit">
		   
</form>

</div>

   
    <div class="copy">
    
</div>
<?php
error_reporting(E_ALL ^ E_NOTICE);  

/////////  connection page /////
require("Connection.php");
    $name=$_POST['name']; 
	$address=$_POST['address'];
	$Gender=$_POST['gender'];  
	$Ward=$_POST['ward'];      
    $Panchayath=$_POST['panchayath'];
	$houseno=$_POST['houseno'];
	$Mobile=$_POST['mobile'];

    $Aadhar=$_FILES['aadhar'];
    $rationcard=$_FILES['rcard'];
   $photo=$_FILES['photo'];
    $email=$_POST['email'];

	$date=$_POST['date'];
	//$Profile_pic=$_FILES["img"]["name"];
if(isset($_POST['submit']))
{

 $sql="INSERT INTO `card_application`( `name`, `gender`, `address`, `Ward`, `Panchayath`,  `Mobile`, `houseno`,`email`,`date`,`status`)
  VALUES('$name','$Gender','$address','$Ward','$Panchayath','$houseno','$Mobile','$email','$date','pending')";
 $result2 = mysqli_query($conn, $sql);
 $z=mysqli_insert_id($conn);
 
 echo "<script>location='#'</script>";
}


?>
		<!-- js -->
  <script type='text/javascript' src='js/jquery-2.2.3.min.js'></script>
<!-- //js -->
<!-- Calendar -->
				<link rel="stylesheet" href="css/jquery-ui.css" />
				<script src="js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
				  </script>
			<!-- //Calendar -->
</body>

</html>