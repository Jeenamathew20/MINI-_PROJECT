
<?php
include "Connection.php";
 	$uname=$_POST['username'];
    $p=$_POST['password'];
	$a="select * from `login` where `Username`='$uname'and`password`='$p'";
	
	$result = mysqli_query($conn, $a) or die( mysqli_error($conn));
	$row=mysqli_fetch_array($result);
	if(!empty($row))
	{
		if($row['role']==1)
		{
			header("Location:../../user/demo1/index.php");
		}
		else 
		{	
			
			header("Location:User_Login.php");
		}
		
	}
		
?>
<?php

include "Connection.php";
    $uname=$_POST['username'];
 	$p=$_POST['password'];
	 
	$v="SELECT `login_id`, `Username`, `password`, `status`, `role`, `reg_id` FROM `login` WHERE `Username`='$uname' and `password`='$p'";
    $a1=mysqli_query($conn,$v);
	$c="SELECT `r_id`, `name`, `Gender`, `Address`, `Ward`, `Panchayath`, `dob`, `Phn_no`, `Adhar_no`, `Card_no`, `img` FROM `registration` WHERE r_id.registeration=reg_id.login";
    $a2=mysqli_query($conn,$c);

	
while($row1=mysqli_fetch_array($a1))
{
	if(!empty($row1))
	 {
         if($row1['role']==1)
         {
         	session_start();
			 $_SESSION['rid']=$rows['r_id'];
			 $_SESSION['lid']=$rows['login_id'];

			 header("Location:../../User/index.php");
         	
       
         }
         else if($row1['role']==2)
         {
         	session_start();
         	
			 header("Location:../../mates/demo1/index.php");
         }
         else
         {
         	session_start();
          header("Location:../../admin/demo1/index.php");
         }
	  }
	 else 
	  {	

		header("Location:User_Login.php?error=Invalid Username/Password!!</center>"); 
	  }
 }
		
?>